SELECT intvalue, t_stamp
FROM public.sqlt_data_1_2023_04
WHERE tagid = 4;

SELECT intvalue, t_stamp AS curr,  lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS prev, t_stamp - lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS diff
FROM public.sqlt_data_1_2023_04
WHERE tagid = 4;

sum(diff) 
FROM

  (SELECT intvalue, t_stamp AS curr,  lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS prev, t_stamp - lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS diff
  FROM public.sqlt_data_1_2023_04
  WHERE tagid = 4) AS aktivnost
WHERE intvalue = 1;

SELECT TO_CHAR((sum || ' second')::interval, 'HH24:MI:SS') 
    FROM (SELECT sum(diff) 
     FROM

       (SELECT intvalue, t_stamp AS curr,  lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS prev, t_stamp - lag(t_stamp, 1) OVER (ORDER BY t_stamp) AS diff
        FROM public.sqlt_data_1_2023_04
        WHERE tagid = 4) AS aktivnost
    WHERE intvalue = 1) as suma;